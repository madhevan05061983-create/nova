import { useState, useEffect, useRef } from "react";

type AuthActionsProps = {
  signedIn: boolean;
  onSignInSuccess: () => void;
  onSignOut: () => void;
};

export function AuthActions({
  signedIn,
  onSignInSuccess,
  onSignOut,
}: AuthActionsProps) {
  const [pending, setPending] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Clean up any polling on unmount
  useEffect(() => {
    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
    };
  }, []);

  // Multi-channel auth listener: postMessage + BroadcastChannel + localStorage
  useEffect(() => {
    const handleAuthSuccess = (sessionId?: string) => {
      if (sessionId) {
        try {
          localStorage.setItem("nova_session_id", sessionId);
        } catch {
          // ignore
        }
      }
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
      setPending(false);
      setErrorMessage(null);
      onSignInSuccess();
    };

    // 1. postMessage listener
    const handleWindowMessage = (event: MessageEvent) => {
      if (event.data?.type === "OAUTH_AUTH_SUCCESS") {
        handleAuthSuccess(event.data.sessionId);
      } else if (event.data?.type === "OAUTH_AUTH_ERROR") {
        setPending(false);
        setErrorMessage(event.data.error || "Authentication was canceled or denied.");
      }
    };
    window.addEventListener("message", handleWindowMessage);

    // 2. BroadcastChannel listener (works across tabs/windows of same origin even if window.opener is null)
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel("nova_auth");
      bc.onmessage = (event) => {
        if (event.data?.type === "OAUTH_AUTH_SUCCESS") {
          handleAuthSuccess(event.data.sessionId);
        }
      };
    } catch {
      // BroadcastChannel not supported in some older environments
    }

    // 3. Storage event listener (syncs state when popup writes to localStorage)
    const handleStorage = (event: StorageEvent) => {
      if (event.key === "nova_auth_success" || event.key === "nova_session_id") {
        const storedToken = localStorage.getItem("nova_session_id") || undefined;
        handleAuthSuccess(storedToken);
      }
    };
    window.addEventListener("storage", handleStorage);

    return () => {
      window.removeEventListener("message", handleWindowMessage);
      window.removeEventListener("storage", handleStorage);
      if (bc) {
        bc.close();
      }
    };
  }, [onSignInSuccess]);

  const handleSignIn = () => {
    setPending(true);
    setErrorMessage(null);

    // Synchronously open popup window on click to guarantee browser popup blockers allow it
    const width = 560;
    const height = 660;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const authWindow = window.open(
      "about:blank",
      "google_oauth_popup",
      `width=${width},height=${height},left=${left},top=${top},status=no,menubar=no,toolbar=no`,
    );

    // Fetch the OAuth URL and redirect the opened popup window
    fetch("/api/auth/url")
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok || !data.url) {
          throw new Error(data.error || "Could not retrieve Google OAuth login URL.");
        }
        if (authWindow) {
          authWindow.location.href = data.url;
        } else {
          window.location.href = data.url;
        }
      })
      .catch((err: unknown) => {
        if (authWindow && !authWindow.closed) {
          authWindow.close();
        }
        setPending(false);
        const msg = err instanceof Error ? err.message : "Error connecting to Google sign-in";
        setErrorMessage(msg);
      });

    // Active polling fallback in case cross-origin restrictions block window.opener
    if (pollTimerRef.current) {
      clearInterval(pollTimerRef.current);
    }

    const checkSession = async () => {
      try {
        const token = localStorage.getItem("nova_session_id");
        const headers: Record<string, string> = {};
        if (token) {
          headers["Authorization"] = `Bearer ${token}`;
        }
        const res = await fetch("/api/auth/session", { headers });
        if (res.ok) {
          const s = await res.json();
          if (s.user) {
            if (pollTimerRef.current) {
              clearInterval(pollTimerRef.current);
              pollTimerRef.current = null;
            }
            if (authWindow && !authWindow.closed) {
              authWindow.close();
            }
            setPending(false);
            setErrorMessage(null);
            onSignInSuccess();
            return true;
          }
        }
      } catch {
        // ignore
      }
      return false;
    };

    pollTimerRef.current = setInterval(async () => {
      const loggedIn = await checkSession();
      if (loggedIn) return;

      if (authWindow?.closed) {
        if (pollTimerRef.current) {
          clearInterval(pollTimerRef.current);
          pollTimerRef.current = null;
        }
        setTimeout(async () => {
          const finished = await checkSession();
          if (!finished) {
            setPending(false);
          }
        }, 600);
      }
    }, 800);
  };

  const handleSignOutClick = async () => {
    setPending(true);
    try {
      const token = localStorage.getItem("nova_session_id");
      const headers: Record<string, string> = {};
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }
      await fetch("/api/auth/signout", { method: "POST", headers });
      try {
        localStorage.removeItem("nova_session_id");
        localStorage.removeItem("nova_auth_success");
      } catch {
        // ignore
      }
      onSignOut();
    } finally {
      setPending(false);
    }
  };

  if (signedIn) {
    return (
      <button
        type="button"
        onClick={handleSignOutClick}
        disabled={pending}
        className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-60 cursor-pointer"
      >
        {pending ? "Signing out…" : "Sign out"}
      </button>
    );
  }

  return (
    <div className="flex flex-col items-center sm:items-end gap-1.5">
      <button
        type="button"
        onClick={handleSignIn}
        disabled={pending}
        className="inline-flex items-center justify-center gap-2.5 rounded-full bg-cyan-400 px-6 py-3 text-sm font-bold text-slate-950 transition hover:bg-cyan-300 active:scale-95 disabled:cursor-not-allowed disabled:opacity-60 shadow-lg shadow-cyan-400/25 cursor-pointer"
      >
        <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24">
          <path
            fill="#4285F4"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="#34A853"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="#FBBC05"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
          />
          <path
            fill="#EA4335"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
          />
        </svg>
        {pending ? "Connecting Google Account…" : "Sign in with Google"}
      </button>

      {errorMessage && (
        <span className="text-[11px] text-rose-300 bg-rose-500/15 border border-rose-500/30 rounded px-2.5 py-1 max-w-sm text-center sm:text-right">
          {errorMessage}
        </span>
      )}
    </div>
  );
}
