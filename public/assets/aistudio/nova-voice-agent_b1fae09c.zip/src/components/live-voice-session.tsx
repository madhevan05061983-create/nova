import { useCallback, useEffect, useRef, useState } from "react";

type LiveVoiceSessionProps = {
  displayName: string;
  onClose: () => void;
};

function downsampleTo16kHz(input: Float32Array, inputSampleRate: number): Int16Array {
  if (inputSampleRate === 16000) {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  const ratio = inputSampleRate / 16000;
  const outputLength = Math.round(input.length / ratio);
  const output = new Int16Array(outputLength);
  for (let i = 0; i < outputLength; i++) {
    const srcIndex = Math.min(Math.round(i * ratio), input.length - 1);
    const s = Math.max(-1, Math.min(1, input[srcIndex]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output;
}

function pcmToBase64(int16Array: Int16Array): string {
  let binary = "";
  const bytes = new Uint8Array(int16Array.buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function LiveVoiceSession({ displayName, onClose }: LiveVoiceSessionProps) {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [micMuted, setMicMuted] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [transcriptHistory, setTranscriptHistory] = useState<string[]>([]);
  const [currentAiTranscript, setCurrentAiTranscript] = useState("");
  const [status, setStatus] = useState("Tap 'Connect Microphone' below to start speaking with Nova.");
  const [micError, setMicError] = useState<string | null>(null);
  const [textInput, setTextInput] = useState("");

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef(0);
  const activeNodesRef = useRef<AudioBufferSourceNode[]>([]);
  const micMutedRef = useRef(micMuted);
  micMutedRef.current = micMuted;

  // Clean shutdown of all audio resources
  const cleanupAudio = useCallback(() => {
    for (const node of activeNodesRef.current) {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // ignore
      }
    }
    activeNodesRef.current = [];

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {
        // ignore
      }
      processorRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        void inputAudioCtxRef.current.close();
      } catch {
        // ignore
      }
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      try {
        void outputAudioCtxRef.current.close();
      } catch {
        // ignore
      }
      outputAudioCtxRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }

    setConnected(false);
    setMicActive(false);
    setIsAiSpeaking(false);
    setMicVolume(0);
  }, []);

  // Initialize Audio Output Context
  const ensureOutputContext = useCallback(() => {
    if (!outputAudioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx({ sampleRate: 24000 });
      outputAudioCtxRef.current = ctx;
      nextStartTimeRef.current = ctx.currentTime;
    }
    if (outputAudioCtxRef.current.state === "suspended") {
      void outputAudioCtxRef.current.resume();
    }
    return outputAudioCtxRef.current;
  }, []);

  // Connect WebSocket to Live API
  const connectWebSocket = useCallback((): Promise<WebSocket> => {
    return new Promise((resolve, reject) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        resolve(wsRef.current);
        return;
      }

      setConnecting(true);
      setStatus("Connecting to Nova Live Voice…");

      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        setConnecting(false);
        setStatus("Connected to Nova Live! Speak naturally.");
        resolve(ws);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === "ready") {
            setStatus("Nova Live is active. Speak into your microphone!");
          } else if (msg.type === "audio" && msg.audio) {
            // Play 24kHz raw PCM chunk
            const binary = atob(msg.audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
              bytes[i] = binary.charCodeAt(i);
            }
            const view = new DataView(bytes.buffer);
            const float32 = new Float32Array(bytes.length / 2);
            for (let i = 0; i < float32.length; i++) {
              const int16 = view.getInt16(i * 2, true);
              float32[i] = int16 < 0 ? int16 / 0x8000 : int16 / 0x7fff;
            }

            const ctx = ensureOutputContext();
            const buffer = ctx.createBuffer(1, float32.length, 24000);
            buffer.copyToChannel(float32, 0);

            const sourceNode = ctx.createBufferSource();
            sourceNode.buffer = buffer;
            sourceNode.connect(ctx.destination);

            const now = ctx.currentTime;
            if (nextStartTimeRef.current < now) {
              nextStartTimeRef.current = now;
            }

            sourceNode.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            activeNodesRef.current.push(sourceNode);
            setIsAiSpeaking(true);

            sourceNode.onended = () => {
              activeNodesRef.current = activeNodesRef.current.filter((n) => n !== sourceNode);
              if (activeNodesRef.current.length === 0) {
                setIsAiSpeaking(false);
              }
            };
          } else if (msg.type === "interrupted") {
            // Stop speech when interrupted by user
            for (const node of activeNodesRef.current) {
              try {
                node.stop();
                node.disconnect();
              } catch {
                // ignore
              }
            }
            activeNodesRef.current = [];
            if (outputAudioCtxRef.current) {
              nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
            }
            setIsAiSpeaking(false);
            setStatus("Nova paused to listen to you.");
          } else if (msg.type === "transcript" && msg.text) {
            setCurrentAiTranscript((prev) => prev + msg.text);
          } else if (msg.type === "turn_complete") {
            setCurrentAiTranscript((prev) => {
              if (prev.trim()) {
                setTranscriptHistory((history) => [...history, prev.trim()]);
              }
              return "";
            });
          } else if (msg.type === "error") {
            setStatus(`Notice: ${msg.error}`);
          }
        } catch (err) {
          console.warn("Live parse error:", err);
        }
      };

      ws.onerror = (e) => {
        console.error("Live WebSocket error:", e);
        setConnecting(false);
        setStatus("Could not connect to Nova Live Voice.");
        reject(new Error("WebSocket error"));
      };

      ws.onclose = () => {
        setConnected(false);
        setConnecting(false);
        setStatus("Nova Live session ended.");
      };
    });
  }, [ensureOutputContext]);

  // Connect microphone directly inside user gesture (click)
  const connectMicrophone = useCallback(async () => {
    setMicError(null);
    setStatus("Requesting microphone access…");

    try {
      // 1. Resume / enable output audio
      ensureOutputContext();

      // 2. Connect WebSocket if not yet connected
      const ws = await connectWebSocket();

      // 3. Request user microphone
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      streamRef.current = stream;

      // 4. Create input AudioContext using device sample rate
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const inputCtx = new AudioCtx();
      inputAudioCtxRef.current = inputCtx;
      if (inputCtx.state === "suspended") {
        await inputCtx.resume();
      }

      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      // Gain node with 0 volume prevents microphone feedback into speakers
      const muteGain = inputCtx.createGain();
      muteGain.gain.value = 0;

      processor.onaudioprocess = (e) => {
        if (micMutedRef.current || ws.readyState !== WebSocket.OPEN) {
          setMicVolume(0);
          return;
        }

        const inputData = e.inputBuffer.getChannelData(0);

        // Compute volume RMS
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        const volumeVal = Math.min(100, Math.round(rms * 280));
        setMicVolume(volumeVal);

        // Downsample input to 16kHz PCM little-endian
        const pcm16 = downsampleTo16kHz(inputData, inputCtx.sampleRate);
        const base64 = pcmToBase64(pcm16);

        ws.send(JSON.stringify({ type: "audio", audio: base64 }));
      };

      source.connect(processor);
      processor.connect(muteGain);
      muteGain.connect(inputCtx.destination);

      setMicActive(true);
      setStatus("Microphone active! Speak now, Nova will hear you and answer back.");
    } catch (err: unknown) {
      console.error("Microphone connection error:", err);
      const isDenied = err instanceof Error && (err.name === "NotAllowedError" || err.name === "PermissionDeniedError");
      if (isDenied) {
        setMicError("Microphone access was blocked by your browser. Please click the 🔒 lock or microphone icon in your browser address bar and choose 'Allow', then click Try Again.");
        setStatus("Microphone permission blocked by browser.");
      } else {
        setMicError("Could not start microphone. You can still type questions below to speak with Nova.");
        setStatus("Microphone unavailable.");
      }
    }
  }, [connectWebSocket, ensureOutputContext]);

  // Connect on mount
  useEffect(() => {
    void connectMicrophone();
    return () => {
      cleanupAudio();
    };
  }, [connectMicrophone, cleanupAudio]);

  const handleSendText = () => {
    if (!textInput.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    const text = textInput.trim();
    wsRef.current.send(JSON.stringify({ type: "text", text }));
    setTextInput("");
    setStatus(`Sent: "${text}"`);
    ensureOutputContext();
  };

  return (
    <div className="rounded-[2.5rem] border border-cyan-400/30 bg-slate-950 p-6 sm:p-8 shadow-[0_24px_90px_rgba(34,211,238,0.2)] backdrop-blur text-white">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 border border-cyan-400/40">
            <span className="text-xl">⚡</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-[0.22em] text-cyan-300">Nova Live Conversation</span>
              <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold border ${
                micActive ? "bg-emerald-400/20 text-emerald-300 border-emerald-400/30" : "bg-amber-400/20 text-amber-300 border-amber-400/30"
              }`}>
                <span className={`h-1.5 w-1.5 rounded-full ${micActive ? "bg-emerald-400 animate-ping" : "bg-amber-400"}`} />
                {micActive ? "Live Voice Connected" : "Connecting Mic…"}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">Direct Real-Time Voice with Nova</h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {micActive && (
            <button
              type="button"
              onClick={() => setMicMuted(!micMuted)}
              className={`rounded-full px-4 py-2 text-xs font-bold transition cursor-pointer ${
                micMuted
                  ? "bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500/30"
                  : "bg-white/10 border border-white/15 text-slate-200 hover:bg-white/20"
              }`}
            >
              {micMuted ? "🔇 Mic Muted" : "🎙️ Mic Active"}
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/10 transition cursor-pointer"
          >
            ✕ Exit Live Mode
          </button>
        </div>
      </div>

      {/* Mic Permission Guidance if blocked */}
      {micError && (
        <div className="mt-4 rounded-2xl border border-rose-500/30 bg-rose-950/40 p-4 text-xs text-rose-200 shadow-lg">
          <div className="flex items-start gap-3">
            <span className="text-xl">🎙️</span>
            <div className="flex-1 space-y-2">
              <p className="font-bold text-white text-sm">Microphone Setup</p>
              <p className="text-slate-300 leading-relaxed">{micError}</p>
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => void connectMicrophone()}
                  className="rounded-full bg-cyan-400 px-4 py-2 font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow"
                >
                  🔄 Connect Microphone Now
                </button>
                <button
                  type="button"
                  onClick={() => setMicError(null)}
                  className="rounded-full border border-white/20 bg-white/5 px-3 py-2 font-medium text-slate-300 hover:bg-white/10 transition cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Interactive Voice Visualizer */}
      <div className="my-8 flex flex-col items-center justify-center text-center">
        {/* Pulsing Voice Orb with reactive audio height */}
        <div className="relative mb-6 flex items-center justify-center">
          <div
            className={`absolute rounded-full transition-all duration-150 ${
              isAiSpeaking
                ? "h-48 w-48 bg-cyan-400/30 blur-2xl animate-pulse"
                : micVolume > 10
                ? "h-40 w-40 bg-emerald-400/25 blur-xl"
                : "h-32 w-32 bg-cyan-400/10 blur-lg"
            }`}
          />

          <button
            type="button"
            onClick={() => {
              if (!micActive) {
                void connectMicrophone();
              }
            }}
            className={`relative flex h-28 w-28 items-center justify-center rounded-full border shadow-2xl transition-all duration-150 cursor-pointer ${
              isAiSpeaking
                ? "border-cyan-300 bg-cyan-950/80 shadow-[0_0_50px_rgba(34,211,238,0.5)] scale-105"
                : micVolume > 10
                ? "border-emerald-400 bg-slate-900 shadow-[0_0_35px_rgba(52,211,153,0.4)] scale-100"
                : "border-cyan-400/40 bg-slate-900 shadow-[0_0_25px_rgba(34,211,238,0.25)] hover:scale-105"
            }`}
            title={micActive ? "Microphone is listening" : "Click to connect microphone"}
          >
            {isAiSpeaking ? (
              // Nova speaking waveform bars
              <div className="flex items-center gap-1">
                <span className="h-6 w-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:-0.4s]" />
                <span className="h-10 w-1.5 rounded-full bg-cyan-300 animate-bounce [animation-delay:-0.2s]" />
                <span className="h-8 w-1.5 rounded-full bg-cyan-200 animate-bounce [animation-delay:-0.3s]" />
                <span className="h-11 w-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:-0.1s]" />
                <span className="h-7 w-1.5 rounded-full bg-cyan-300 animate-bounce [animation-delay:-0.25s]" />
              </div>
            ) : micVolume > 10 ? (
              // User speaking audio feedback
              <div className="flex items-center gap-1">
                <span className="h-4 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="h-7 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
                <span className="h-9 w-1.5 rounded-full bg-emerald-200 animate-pulse" />
                <span className="h-6 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
              </div>
            ) : (
              <span className="text-3xl text-cyan-300">{micActive ? "🎙️" : "🔌"}</span>
            )}
          </button>
        </div>

        {!micActive && (
          <button
            type="button"
            onClick={() => void connectMicrophone()}
            disabled={connecting}
            className="mb-3 rounded-full bg-cyan-400 px-6 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow-lg shadow-cyan-400/25"
          >
            {connecting ? "Connecting…" : "🎙️ Enable Microphone & Start Talking"}
          </button>
        )}

        <p className="text-sm font-semibold text-white">
          {isAiSpeaking ? "Nova is speaking to you…" : micMuted ? "Microphone is muted." : micActive ? "Listening… Speak anytime to chat with Nova." : "Microphone not connected."}
        </p>
        <p className="mt-1 text-xs text-slate-400 max-w-md">{status}</p>

        {isAiSpeaking && (
          <p className="mt-2 text-[11px] text-cyan-300/80 bg-cyan-400/10 border border-cyan-400/20 rounded-full px-3 py-1">
            💡 You can speak to interrupt Nova naturally at any moment.
          </p>
        )}
      </div>

      {/* Live Transcript Stream */}
      {(currentAiTranscript || transcriptHistory.length > 0) && (
        <div className="mt-6 rounded-2xl border border-white/10 bg-slate-900/60 p-4 max-h-[220px] overflow-y-auto space-y-2 text-xs sm:text-sm">
          {transcriptHistory.map((text, idx) => (
            <div key={idx} className="flex gap-2 text-slate-300">
              <span className="font-bold text-cyan-400 shrink-0">Nova:</span>
              <span>{text}</span>
            </div>
          ))}
          {currentAiTranscript && (
            <div className="flex gap-2 text-cyan-100">
              <span className="font-bold text-cyan-300 shrink-0">Nova:</span>
              <span className="animate-pulse">{currentAiTranscript}</span>
            </div>
          )}
        </div>
      )}

      {/* Text fallback input during live session */}
      <div className="mt-6 flex gap-2">
        <input
          type="text"
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSendText()}
          placeholder="Or type a question to speak with Nova…"
          className="flex-1 rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 outline-none"
        />
        <button
          type="button"
          onClick={handleSendText}
          disabled={!connected || !textInput.trim()}
          className="rounded-2xl bg-cyan-400 px-5 py-3 text-xs sm:text-sm font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50 transition cursor-pointer"
        >
          Send
        </button>
      </div>
    </div>
  );
}
