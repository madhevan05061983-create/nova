import { useCallback, useEffect, useRef, useState } from "react";
import type { NovaIntent, NovaResponse } from "../lib/nova.ts";
import { LiveVoiceSession } from "./live-voice-session.tsx";

type SpeechRecognitionAlternativeLike = {
  transcript: string;
};

type SpeechRecognitionResultLike = ArrayLike<SpeechRecognitionAlternativeLike> & {
  isFinal?: boolean;
  [index: number]: SpeechRecognitionAlternativeLike;
};

type SpeechRecognitionEventLike = {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike> & {
    [index: number]: SpeechRecognitionResultLike;
  };
};

type SpeechRecognitionInstanceLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives?: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

type SpeechRecognitionConstructorLike = new () => SpeechRecognitionInstanceLike;

type WindowWithSpeech = Window & {
  SpeechRecognition?: SpeechRecognitionConstructorLike;
  webkitSpeechRecognition?: SpeechRecognitionConstructorLike;
};

export type NovaMessage = {
  id: string;
  role: "assistant" | "user";
  content: string;
  timestamp: number;
  intent?: NovaIntent;
  actionUrl?: string;
  actionLabel?: string;
};

type TrackedTab = {
  id: string;
  url: string;
  label: string;
  openedAt: number;
};

type NovaConsoleProps = {
  displayName: string;
  email: string;
  onSignOut: () => void;
};

const initialAssistantMessage: NovaMessage = {
  id: "nova-welcome",
  role: "assistant",
  content:
    "Hello, I am Nova. Tap the microphone or type below. I will answer your questions, speak aloud, and open or close browser tabs to do tasks.",
  intent: "general",
  timestamp: Date.now(),
};

const CHAT_STORAGE_KEY = "nova_chat_history_v1";

function loadStoredMessages(): NovaMessage[] {
  if (typeof window === "undefined") return [initialAssistantMessage];
  try {
    const raw = localStorage.getItem(CHAT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return [initialAssistantMessage];
}

function formatMessageTime(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(timestamp));
  } catch {
    return "";
  }
}

function getSpeechRecognition(): SpeechRecognitionConstructorLike | undefined {
  if (typeof window === "undefined") {
    return undefined;
  }
  const speechWindow = window as WindowWithSpeech;
  return speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
}

export function NovaConsole({ displayName, email, onSignOut }: NovaConsoleProps) {
  const [messages, setMessages] = useState<NovaMessage[]>(loadStoredMessages);
  const [draft, setDraft] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([
    "Open YouTube",
    "Close tabs",
    "Open Google",
    "What time is it?",
  ]);
  const [status, setStatus] = useState("Ready and waiting for your voice command.");
  const [listening, setListening] = useState(false);
  const [sending, setSending] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [speechRate, setSpeechRate] = useState(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>("");
  const [micPermissionError, setMicPermissionError] = useState<string | null>(null);
  const [liveMode, setLiveMode] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Tab tracking for Close Tabs functionality
  const [activeTabs, setActiveTabs] = useState<TrackedTab[]>([]);
  const openedTabsRef = useRef<Map<string, Window>>(new Map());

  const activeRecognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const pendingTranscriptRef = useRef("");
  const autoSpeakRef = useRef(autoSpeak);
  autoSpeakRef.current = autoSpeak;
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-save chat history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // ignore
    }
  }, [messages]);

  // Auto-scroll chat history to bottom
  const scrollToBottom = useCallback((smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
    }
  }, []);

  useEffect(() => {
    scrollToBottom(true);
  }, [messages, scrollToBottom]);

  // Load available speech synthesis voices
  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    const updateVoices = () => {
      const available = window.speechSynthesis.getVoices();
      if (available.length > 0) {
        setVoices(available);
        const bestVoice =
          available.find((v) => v.lang.startsWith("en") && (v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Samantha"))) ||
          available.find((v) => v.lang.startsWith("en")) ||
          available[0];
        if (bestVoice && !selectedVoiceName) {
          setSelectedVoiceName(bestVoice.name);
        }
      }
    };

    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;

    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [selectedVoiceName]);

  // Reliable Speech Synthesis Method
  const speakText = useCallback(
    (textToSpeak: string, shouldSignOut = false) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) {
        if (shouldSignOut) onSignOut();
        return;
      }

      try {
        window.speechSynthesis.cancel();
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }

        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.lang = "en-US";
        utterance.rate = speechRate;
        utterance.pitch = 1.0;

        if (selectedVoiceName && voices.length > 0) {
          const matchedVoice = voices.find((v) => v.name === selectedVoiceName);
          if (matchedVoice) {
            utterance.voice = matchedVoice;
          }
        }

        utterance.onstart = () => {
          setIsSpeaking(true);
        };

        utterance.onend = () => {
          setIsSpeaking(false);
          if (shouldSignOut) {
            onSignOut();
          }
        };

        utterance.onerror = (e) => {
          console.warn("Speech synthesis notice:", e);
          setIsSpeaking(false);
          if (shouldSignOut) {
            onSignOut();
          }
        };

        setTimeout(() => {
          window.speechSynthesis.speak(utterance);
        }, 30);
      } catch (err) {
        console.error("Speech error:", err);
        setIsSpeaking(false);
        if (shouldSignOut) onSignOut();
      }
    },
    [onSignOut, speechRate, selectedVoiceName, voices],
  );

  const stopSpeaking = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  // Function to execute Tab Closing
  const closeTabs = useCallback(
    (target: string = "all") => {
      let closedCount = 0;

      if (target === "all") {
        openedTabsRef.current.forEach((win) => {
          if (win && !win.closed) {
            try {
              win.close();
              closedCount++;
            } catch {
              // ignore
            }
          }
        });
        openedTabsRef.current.clear();
        setActiveTabs([]);
        const msg = closedCount > 0 ? `Closed ${closedCount} opened browser tab(s).` : "No active opened tabs to close.";
        setStatus(msg);
        return msg;
      } else if (target === "last") {
        const keys = Array.from(openedTabsRef.current.keys());
        const lastKey = keys[keys.length - 1];
        if (lastKey) {
          const win = openedTabsRef.current.get(lastKey);
          if (win && !win.closed) {
            try {
              win.close();
              closedCount++;
            } catch {
              // ignore
            }
          }
          openedTabsRef.current.delete(lastKey);
          setActiveTabs((prev) => prev.filter((t) => t.id !== lastKey));
          setStatus("Closed the most recently opened tab.");
          return "Closed the most recently opened tab.";
        }
        setStatus("No opened tabs found to close.");
        return "No opened tabs found to close.";
      } else {
        // target matches a specific keyword e.g. "youtube", "google"
        const toRemove: string[] = [];
        openedTabsRef.current.forEach((win, id) => {
          const tab = activeTabs.find((t) => t.id === id);
          if (tab && (tab.label.toLowerCase().includes(target.toLowerCase()) || tab.url.toLowerCase().includes(target.toLowerCase()))) {
            if (win && !win.closed) {
              try {
                win.close();
                closedCount++;
              } catch {
                // ignore
              }
            }
            toRemove.push(id);
          }
        });

        toRemove.forEach((id) => openedTabsRef.current.delete(id));
        setActiveTabs((prev) => prev.filter((t) => !toRemove.includes(t.id)));
        const msg = closedCount > 0 ? `Closed ${target} tab.` : `No open ${target} tab found.`;
        setStatus(msg);
        return msg;
      }
    },
    [activeTabs],
  );

  const closeSingleTab = useCallback((tabId: string) => {
    const win = openedTabsRef.current.get(tabId);
    if (win && !win.closed) {
      try {
        win.close();
      } catch {
        // ignore
      }
    }
    openedTabsRef.current.delete(tabId);
    setActiveTabs((prev) => prev.filter((t) => t.id !== tabId));
    setStatus("Closed tab.");
  }, []);

  const clearChatHistory = useCallback(() => {
    if (window.confirm("Are you sure you want to clear your chat history with Nova?")) {
      const reset = [initialAssistantMessage];
      setMessages(reset);
      try {
        localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(reset));
      } catch {
        // ignore
      }
      setStatus("Chat history cleared.");
    }
  }, []);

  const handleCopyMessage = useCallback((id: string, text: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // ignore
    }
  }, []);

  const submitTranscript = useCallback(
    async (transcript: string) => {
      const cleanTranscript = transcript.trim();
      if (!cleanTranscript || sending) {
        return;
      }

      const userMsg: NovaMessage = {
        id: crypto.randomUUID(),
        role: "user",
        content: cleanTranscript,
        timestamp: Date.now(),
      };

      setMessages((current) => [...current, userMsg]);
      setDraft("");
      setSending(true);
      setStatus("Nova is processing your voice request…");

      try {
        const token = typeof window !== "undefined" ? localStorage.getItem("nova_session_id") : null;
        const headers: Record<string, string> = {
          "Content-Type": "application/json",
        };
        if (token) {
          headers["Authorization"] = `Bearer ${token}`;
        }

        const response = await fetch("/api/nova", {
          method: "POST",
          headers,
          body: JSON.stringify({ transcript: cleanTranscript }),
        });

        if (!response.ok) {
          const error = (await response.json().catch(() => null)) as { error?: string } | null;
          throw new Error(error?.error ?? "Nova could not reach the voice service.");
        }

        const data = (await response.json()) as NovaResponse;

        const action = data.action;

        // Execute Tab Actions
        if (action && action.type === "open_url") {
          try {
            const win = window.open(action.url, "_blank");
            if (win) {
              const tabId = crypto.randomUUID();
              openedTabsRef.current.set(tabId, win);
              setActiveTabs((prev) => [
                ...prev,
                {
                  id: tabId,
                  url: action.url,
                  label: action.label || action.url || "Web Tab",
                  openedAt: Date.now(),
                },
              ]);
            }
          } catch {
            // Popup blocker fallback
          }
        } else if (action && action.type === "close_tabs") {
          closeTabs(action.target || "all");
        }

        const assistantMessage: NovaMessage = {
          id: crypto.randomUUID(),
          role: "assistant",
          content: data.reply,
          timestamp: Date.now(),
          intent: data.intent,
          actionUrl: action && action.type === "open_url" ? action.url : undefined,
          actionLabel: action && action.type === "open_url" ? action.label || action.url : undefined,
        };

        setMessages((current) => [...current, assistantMessage]);
        setSuggestions(data.suggestions.length > 0 ? data.suggestions : ["Open YouTube", "Close tabs", "Open Google"]);
        setStatus(
          data.intent === "sign_out"
            ? "Signing you out."
            : data.action?.type === "close_tabs"
            ? `Tabs closed.`
            : data.action
            ? `Task executed: ${data.action.label || "Done"}`
            : "Nova answered.",
        );

        if (autoSpeakRef.current || data.intent === "sign_out") {
          speakText(data.reply, data.intent === "sign_out");
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : "Nova encountered an unexpected error.";
        setStatus(message);
        setMessages((current) => [
          ...current,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: message,
            timestamp: Date.now(),
            intent: "general",
          },
        ]);
        if (autoSpeakRef.current) {
          speakText(message);
        }
      } finally {
        setSending(false);
      }
    },
    [sending, speakText, closeTabs],
  );

  // Stop recognition on unmount
  useEffect(() => {
    return () => {
      if (activeRecognitionRef.current) {
        try {
          activeRecognitionRef.current.abort();
        } catch {
          // ignore
        }
        activeRecognitionRef.current = null;
      }
    };
  }, []);

  // Fresh SpeechRecognition instance created dynamically on every Tap
  const startListening = useCallback(async () => {
    stopSpeaking();
    setMicPermissionError(null);

    const Recognition = getSpeechRecognition();
    if (!Recognition) {
      setMicPermissionError("Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari, or type your message below.");
      setStatus("Speech recognition not supported in current browser.");
      return;
    }

    // Stop any active recognition instance
    if (activeRecognitionRef.current) {
      try {
        activeRecognitionRef.current.abort();
      } catch {
        // ignore
      }
      activeRecognitionRef.current = null;
    }

    // Create a fresh instance for this interaction
    try {
      const recognition = new Recognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = typeof navigator !== "undefined" && navigator.language ? navigator.language : "en-US";
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setListening(true);
        setStatus("Listening… Speak into your microphone now.");
      };

      recognition.onresult = (event) => {
        let finalTranscript = "";
        let interimTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const res = event.results[i];
          if (res.isFinal) {
            finalTranscript += res[0].transcript;
          } else {
            interimTranscript += res[0].transcript;
          }
        }

        const currentText = (finalTranscript || interimTranscript).trim();
        if (currentText) {
          pendingTranscriptRef.current = currentText;
          setDraft(currentText);
          setStatus(`Heard: “${currentText}”`);
        }
      };

      recognition.onerror = (event) => {
        setListening(false);
        console.warn("Speech recognition notice:", event.error);
        if (event.error === "no-speech") {
          setStatus("No speech heard. Tap the mic and speak clearly, or type below.");
        } else if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          setMicPermissionError(
            "Microphone access is currently blocked in your browser. Click the lock/microphone icon in the address bar at the top, change Microphone to 'Allow', and tap Try Again!"
          );
          setStatus("Microphone permission blocked by browser.");
        } else if (event.error === "network") {
          setStatus("Network speech service notice. Check your internet connection.");
        } else {
          setStatus(`Microphone note: ${event.error}. You can also type below.`);
        }
      };

      recognition.onend = () => {
        setListening(false);
        const textToSubmit = pendingTranscriptRef.current.trim();
        pendingTranscriptRef.current = "";
        if (textToSubmit) {
          void submitTranscript(textToSubmit);
        }
      };

      activeRecognitionRef.current = recognition;
      pendingTranscriptRef.current = "";
      recognition.start();
    } catch (err: unknown) {
      setListening(false);
      console.error("Failed to start speech recognition:", err);
      setStatus("Could not start microphone. Check browser microphone permissions.");
    }
  }, [stopSpeaking, submitTranscript]);

  const stopListening = useCallback(() => {
    if (activeRecognitionRef.current) {
      try {
        activeRecognitionRef.current.stop();
      } catch {
        // ignore
      }
    }
    setListening(false);
  }, []);

  const handleSend = useCallback(() => {
    const transcript = draft.trim();
    if (!transcript) {
      setStatus("Type or speak a command before sending.");
      return;
    }
    void submitTranscript(transcript);
  }, [draft, submitTranscript]);

  if (liveMode) {
    return <LiveVoiceSession displayName={displayName} onClose={() => setLiveMode(false)} />;
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.22fr_0.78fr]">
      {/* Left Column: Voice Conversation Console & Scrollable Chat History */}
      <div className="flex flex-col rounded-[2rem] border border-white/10 bg-slate-950/80 p-6 shadow-[0_24px_80px_rgba(15,23,42,0.45)] backdrop-blur">
        {/* Header section with live toggle & test voice */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-[0.24em] text-cyan-300">Nova Console</span>
              {isSpeaking && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-cyan-400/20 px-2.5 py-0.5 text-[11px] font-semibold text-cyan-300 border border-cyan-400/30">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-ping" />
                  Speaking Now
                </span>
              )}
            </div>
            <h2 className="mt-1 text-2xl font-bold text-white">Welcome, {displayName}</h2>
            <p className="text-xs text-slate-400">{email}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLiveMode(true)}
              className="inline-flex items-center gap-1.5 rounded-full bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow-md shadow-cyan-400/25 active:scale-95"
              title="Start real-time continuous voice conversation with Nova"
            >
              <span>⚡</span> Nova Live Conversation
            </button>

            {isSpeaking ? (
              <button
                type="button"
                onClick={stopSpeaking}
                className="inline-flex items-center gap-1.5 rounded-full bg-rose-500/20 border border-rose-500/40 px-3.5 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-500/30 transition cursor-pointer"
              >
                <span>⏹</span> Stop Speaking
              </button>
            ) : (
              <button
                type="button"
                onClick={() => speakText("Nova voice system is active and ready to speak your commands.")}
                className="inline-flex items-center gap-1.5 rounded-full bg-white/10 border border-white/15 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-white/20 transition cursor-pointer"
              >
                <span>🔊</span> Test Voice
              </button>
            )}
          </div>
        </div>

        {/* Permission Guide if microphone is blocked */}
        {micPermissionError && (
          <div className="mt-4 rounded-2xl border border-rose-500/30 bg-rose-950/30 p-4 text-xs text-rose-200 shadow-lg">
            <div className="flex items-start gap-3">
              <span className="text-xl">🎙️</span>
              <div className="flex-1 space-y-2">
                <p className="font-bold text-white text-sm">Microphone Permission Notice</p>
                <p className="text-slate-300 leading-relaxed">{micPermissionError}</p>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setMicPermissionError(null);
                      void startListening();
                    }}
                    className="rounded-full bg-cyan-400 px-4 py-2 font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow"
                  >
                    🔄 Try Microphone Again
                  </button>
                  <button
                    type="button"
                    onClick={() => setMicPermissionError(null)}
                    className="rounded-full border border-white/20 bg-white/5 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-white/10 transition cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Controls: Mic button, Send button, Status */}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={listening ? stopListening : startListening}
            className={`inline-flex items-center gap-2.5 rounded-full px-6 py-3.5 text-sm font-bold transition shadow-lg cursor-pointer ${
              listening
                ? "bg-rose-500 text-white animate-pulse shadow-rose-500/30"
                : "bg-cyan-400 text-slate-950 hover:bg-cyan-300 shadow-cyan-400/25 active:scale-95"
            }`}
          >
            <span aria-hidden="true" className="text-lg">{listening ? "◼" : "🎙️"}</span>
            {listening ? "Stop Listening" : "Tap to Speak"}
          </button>

          <button
            type="button"
            onClick={handleSend}
            disabled={sending}
            className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/10 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-60 cursor-pointer"
          >
            {sending ? "Processing…" : "Send"}
          </button>

          <div className="flex items-center gap-2 text-xs text-slate-300">
            {isSpeaking && (
              <div className="flex items-center gap-0.5">
                <span className="h-3 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="h-4 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="h-5 w-1 bg-cyan-400 rounded-full animate-bounce" />
                <span className="h-3 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.2s]" />
              </div>
            )}
            <span>{status}</span>
          </div>
        </div>

        {/* Input Textarea */}
        <label className="mt-4 block">
          <span className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-300">
            Spoken / Written Command
          </span>
          <textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            rows={2}
            placeholder="Speak into microphone or type anything, e.g. ‘Open YouTube’, ‘Close tabs’, ‘What time is it?’"
            className="w-full rounded-2xl border border-white/10 bg-slate-900/90 px-4 py-2.5 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
          />
        </label>

        {/* Suggestion Quick Action Pills */}
        <div className="mt-3 flex flex-wrap gap-2">
          {suggestions.map((action: string) => (
            <button
              key={action}
              type="button"
              onClick={() => {
                setDraft(action);
                void submitTranscript(action);
              }}
              className="rounded-full border border-cyan-400/25 bg-cyan-400/5 px-3 py-1.5 text-xs font-medium text-cyan-200 transition hover:border-cyan-400 hover:bg-cyan-400/15 cursor-pointer"
            >
              💬 {action}
            </button>
          ))}
        </div>

        {/* Scrollable Message List / Chat History Header */}
        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4 pb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Conversation History
            </span>
            <span className="rounded-full bg-cyan-400/15 px-2 py-0.5 text-[10px] font-semibold text-cyan-300 border border-cyan-400/20">
              {messages.length} message{messages.length === 1 ? "" : "s"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => scrollToBottom(true)}
              className="rounded-full px-2.5 py-1 text-[11px] text-slate-400 hover:text-white hover:bg-white/5 transition cursor-pointer"
              title="Scroll to latest message"
            >
              ↓ Latest
            </button>
            <button
              type="button"
              onClick={clearChatHistory}
              className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-medium text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 hover:border-rose-500/20 transition cursor-pointer"
              title="Clear stored conversation history"
            >
              Clear History
            </button>
          </div>
        </div>

        {/* Scrollable Message List Container */}
        <div className="mt-2 space-y-3.5 max-h-[440px] overflow-y-auto pr-2 custom-scrollbar flex-1">
          {messages.map((message) => {
            const isUser = message.role === "user";
            return (
              <article
                key={message.id}
                className={`rounded-2xl border p-4 text-sm leading-relaxed transition ${
                  isUser
                    ? "border-white/10 bg-white/5 text-slate-100 ml-6"
                    : "border-cyan-400/25 bg-cyan-950/20 text-cyan-50 mr-6 shadow-sm"
                }`}
              >
                {/* Message Header Bar */}
                <div className="mb-2 flex items-center justify-between border-b border-white/5 pb-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                        isUser
                          ? "bg-slate-800 text-slate-300 border border-slate-700"
                          : "bg-cyan-400/20 text-cyan-300 border border-cyan-400/30"
                      }`}
                    >
                      {isUser ? "You" : "Nova"}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {formatMessageTime(message.timestamp)}
                    </span>
                    {message.intent && !isUser && (
                      <span className="rounded bg-white/5 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-slate-400">
                        {message.intent.replace("_", " ")}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Action link if URL was opened */}
                    {message.actionUrl && (
                      <a
                        href={message.actionUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded bg-cyan-400/20 px-2 py-0.5 text-[11px] font-semibold text-cyan-300 hover:bg-cyan-400/30 transition flex items-center gap-1"
                      >
                        ↗ Open {message.actionLabel || "Tab"}
                      </a>
                    )}

                    {/* Copy text button */}
                    <button
                      type="button"
                      onClick={() => handleCopyMessage(message.id, message.content)}
                      className="rounded px-2 py-0.5 text-xs text-slate-400 hover:bg-white/10 hover:text-white transition cursor-pointer"
                      title="Copy message to clipboard"
                    >
                      {copiedId === message.id ? "✓ Copied" : "📋 Copy"}
                    </button>

                    {/* Speak aloud button */}
                    <button
                      type="button"
                      onClick={() => speakText(message.content)}
                      className="rounded px-2 py-0.5 text-xs text-slate-400 hover:bg-white/10 hover:text-cyan-300 transition flex items-center gap-1 cursor-pointer"
                      title="Speak this response aloud"
                    >
                      🔊 Speak
                    </button>
                  </div>
                </div>

                {/* Message Body */}
                <p className="text-sm sm:text-base whitespace-pre-wrap">{message.content}</p>
              </article>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Right Column: Voice & Browser Tab Management */}
      <aside className="space-y-5 rounded-[2rem] border border-white/10 bg-slate-900/80 p-6 text-white shadow-[0_24px_80px_rgba(15,23,42,0.3)] backdrop-blur flex flex-col">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.24em] text-cyan-400">Controls & Tasks</span>
          <h3 className="mt-1 text-xl font-bold text-white">Voice & Tab Manager</h3>
          <p className="mt-1 text-xs text-slate-300">
            Manage opened browser tabs, speech rate, and automation tasks.
          </p>
        </div>

        {/* ACTIVE OPENED TABS SECTION (Working of Close Tabs) */}
        <div className="rounded-2xl border border-cyan-400/30 bg-slate-950 p-4 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                Active Opened Tabs
              </span>
              <span className="rounded-full bg-cyan-400/20 px-2 py-0.5 text-[10px] font-bold text-cyan-300">
                {activeTabs.length}
              </span>
            </div>

            {activeTabs.length > 0 && (
              <button
                type="button"
                onClick={() => closeTabs("all")}
                className="rounded-full bg-rose-500/20 border border-rose-500/40 px-2.5 py-1 text-[11px] font-bold text-rose-300 hover:bg-rose-500/30 transition cursor-pointer"
              >
                ✕ Close All Tabs
              </button>
            )}
          </div>

          {activeTabs.length === 0 ? (
            <p className="text-xs text-slate-400 py-1">
              No tabs opened by Nova currently. Ask Nova e.g. <span className="text-cyan-300 italic">“Open YouTube”</span> or <span className="text-cyan-300 italic">“Open Google”</span>.
            </p>
          ) : (
            <div className="space-y-2 mt-2">
              {activeTabs.map((tab) => (
                <div
                  key={tab.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs"
                >
                  <div className="truncate flex-1">
                    <p className="font-semibold text-white truncate">{tab.label}</p>
                    <p className="text-[10px] text-slate-400 truncate">{tab.url}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => closeSingleTab(tab.id)}
                    className="shrink-0 rounded-lg bg-rose-500/20 border border-rose-500/30 px-2.5 py-1 text-[11px] font-bold text-rose-300 hover:bg-rose-500/30 transition cursor-pointer"
                    title={`Close ${tab.label}`}
                  >
                    ✕ Close Tab
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Tab Automation Quick Tasks */}
        <div className="space-y-3 rounded-2xl bg-slate-950 p-4 border border-white/10">
          <p className="text-xs font-bold uppercase tracking-wider text-cyan-300">
            Open & Close Tab Commands
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            Nova can open websites and close them on command:
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => void submitTranscript("Open Google")}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 p-2.5 text-xs font-semibold text-slate-200 hover:bg-white/10 transition cursor-pointer"
            >
              <span>🌐</span> Open Google
            </button>

            <button
              type="button"
              onClick={() => void submitTranscript("Open YouTube")}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 p-2.5 text-xs font-semibold text-slate-200 hover:bg-white/10 transition cursor-pointer"
            >
              <span>▶️</span> Open YouTube
            </button>

            <button
              type="button"
              onClick={() => void submitTranscript("Open GitHub")}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 p-2.5 text-xs font-semibold text-slate-200 hover:bg-white/10 transition cursor-pointer"
            >
              <span>🐙</span> Open GitHub
            </button>

            <button
              type="button"
              onClick={() => void submitTranscript("Close tabs")}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 p-2.5 text-xs font-semibold text-rose-200 hover:bg-rose-500/20 transition cursor-pointer"
            >
              <span>✕</span> Close Tabs
            </button>
          </div>
        </div>

        {/* Speech Playback Controls */}
        <div className="space-y-3.5 rounded-2xl bg-slate-950 p-4 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Auto-Speak Responses</span>
            <button
              type="button"
              onClick={() => setAutoSpeak(!autoSpeak)}
              className={`rounded-full px-3 py-1 text-xs font-bold transition cursor-pointer ${
                autoSpeak ? "bg-cyan-400 text-slate-950" : "bg-white/10 text-slate-400"
              }`}
            >
              {autoSpeak ? "🔊 ON" : "🔇 OFF"}
            </button>
          </div>

          {/* Voice Speed */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
              <span>Speaking Speed</span>
              <span className="font-mono text-cyan-300">{speechRate}x</span>
            </div>
            <div className="flex gap-2">
              {[0.9, 1.0, 1.15, 1.3].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => setSpeechRate(rate)}
                  className={`flex-1 rounded-xl py-1 text-xs font-semibold transition cursor-pointer ${
                    speechRate === rate
                      ? "bg-cyan-400 text-slate-950"
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          {/* Voice Selection */}
          {voices.length > 0 && (
            <div>
              <label className="block text-xs text-slate-300 mb-1">Voice Accent / Voice</label>
              <select
                value={selectedVoiceName}
                onChange={(e) => setSelectedVoiceName(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-slate-200 outline-none focus:border-cyan-400 cursor-pointer"
              >
                {voices
                  .filter((v) => v.lang.startsWith("en"))
                  .slice(0, 15)
                  .map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
              </select>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
