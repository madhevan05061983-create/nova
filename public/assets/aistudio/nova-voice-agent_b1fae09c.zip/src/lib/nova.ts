export type NovaIntent = "general" | "security" | "sign_out" | "time" | "open_tab" | "close_tab";

export type NovaAction =
  | {
      type: "open_url";
      url: string;
      label?: string;
    }
  | {
      type: "close_tabs";
      target?: string; // "all" | "last" | "youtube" | "google" | "github"
      label?: string;
    };

export type NovaResponse = {
  reply: string;
  intent: NovaIntent;
  suggestions: string[];
  action?: NovaAction;
};

const MAX_TRANSCRIPT_LENGTH = 500;
const DEFAULT_OPENROUTER_KEY = "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";

export function normalizeTranscript(transcript: string) {
  return transcript.trim().replace(/\s+/g, " ").slice(0, MAX_TRANSCRIPT_LENGTH);
}

export function formatCurrentTime() {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "full",
    timeStyle: "short",
  }).format(new Date());
}

function hasAny(text: string, phrases: string[]) {
  return phrases.some((phrase) => text.includes(phrase));
}

function cleanSpokenText(text: string): string {
  return text
    .replace(/[*#_`~]/g, "")
    .replace(/\[.*?\]\(.*?\)/g, "")
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "")
    .trim();
}

export async function createNovaResponse(
  transcript: string,
  userLabel: string,
  customApiKey?: string,
): Promise<NovaResponse> {
  const cleanTranscript = normalizeTranscript(transcript);
  const lower = cleanTranscript.toLowerCase();
  const greetingName = userLabel ? `, ${userLabel}` : "";

  if (!cleanTranscript) {
    return {
      reply: `I didn’t catch that${greetingName}. Please speak clearly into your microphone or type a question.`,
      intent: "general",
      suggestions: ["What can you do?", "What time is it?", "Open YouTube"],
    };
  }

  // 1. Voice Sign-Out Command
  if (hasAny(lower, ["sign out", "log out", "logout", "sign me out", "goodbye nova"])) {
    return {
      reply: "Understood. Signing you out securely now.",
      intent: "sign_out",
      suggestions: ["Sign in with Google again"],
    };
  }

  // 2. Close Tabs Commands
  if (
    hasAny(lower, [
      "close tabs",
      "close all tabs",
      "close open tabs",
      "close opened tabs",
      "close the tabs",
      "close browser tabs",
    ])
  ) {
    return {
      reply: "Closing all opened browser tabs for you.",
      intent: "close_tab",
      suggestions: ["Open YouTube", "Open Google", "What time is it?"],
      action: { type: "close_tabs", target: "all", label: "All Opened Tabs" },
    };
  }

  if (
    hasAny(lower, [
      "close tab",
      "close the tab",
      "close current tab",
      "close last tab",
      "close this tab",
    ])
  ) {
    return {
      reply: "Closing the most recently opened tab.",
      intent: "close_tab",
      suggestions: ["Open Google", "Open YouTube", "What time is it?"],
      action: { type: "close_tabs", target: "last", label: "Last Opened Tab" },
    };
  }

  if (lower.startsWith("close youtube") || lower === "exit youtube") {
    return {
      reply: "Closing the YouTube tab.",
      intent: "close_tab",
      suggestions: ["Open Google", "What time is it?"],
      action: { type: "close_tabs", target: "youtube", label: "YouTube Tab" },
    };
  }

  if (lower.startsWith("close google") || lower === "exit google") {
    return {
      reply: "Closing the Google tab.",
      intent: "close_tab",
      suggestions: ["Open YouTube", "What time is it?"],
      action: { type: "close_tabs", target: "google", label: "Google Tab" },
    };
  }

  if (lower.startsWith("close github") || lower === "exit github") {
    return {
      reply: "Closing the GitHub tab.",
      intent: "close_tab",
      suggestions: ["Open Google", "What can you do?"],
      action: { type: "close_tabs", target: "github", label: "GitHub Tab" },
    };
  }

  // 3. Direct Browser Task Actions (Open new tabs, search, websites)
  if (lower.startsWith("open youtube") || lower === "youtube") {
    return {
      reply: "Opening YouTube in a new tab.",
      intent: "open_tab",
      suggestions: ["Close tabs", "Open Google", "What time is it?"],
      action: { type: "open_url", url: "https://www.youtube.com", label: "YouTube" },
    };
  }

  if (lower.startsWith("open google") || lower === "google") {
    return {
      reply: "Opening Google in a new tab for you.",
      intent: "open_tab",
      suggestions: ["Close tabs", "Search for AI news", "What time is it?"],
      action: { type: "open_url", url: "https://www.google.com", label: "Google" },
    };
  }

  if (lower.startsWith("open github") || lower === "github") {
    return {
      reply: "Opening GitHub in a new tab.",
      intent: "open_tab",
      suggestions: ["Close tabs", "Open Google", "What can you do?"],
      action: { type: "open_url", url: "https://github.com", label: "GitHub" },
    };
  }

  if (lower.startsWith("search google for ") || lower.startsWith("google ") || lower.startsWith("search for ")) {
    const query = lower
      .replace(/^search google for /, "")
      .replace(/^google /, "")
      .replace(/^search for /, "")
      .trim();
    if (query) {
      return {
        reply: `Searching Google for ${query} in a new tab.`,
        intent: "open_tab",
        suggestions: ["Close tabs", "Open YouTube", "What time is it?"],
        action: {
          type: "open_url",
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
          label: `Search: ${query}`,
        },
      };
    }
  }

  if (hasAny(lower, ["open new tab", "open a new tab", "new tab", "open browser"])) {
    return {
      reply: "Opening a new browser tab for you.",
      intent: "open_tab",
      suggestions: ["Close tabs", "Search for AI news", "What time is it?"],
      action: { type: "open_url", url: "https://www.google.com", label: "New Tab" },
    };
  }

  // 4. Date & Time Queries
  if (
    hasAny(lower, [
      "what time is it",
      "current time",
      "what's the time",
      "tell me the time",
      "what is today's date",
      "what is today’s date",
      "what is the date",
      "what date is today",
      "what is the time and date",
      "what is today's date and time",
      "what is today’s date and time",
    ])
  ) {
    return {
      reply: `It is currently ${formatCurrentTime()}.`,
      intent: "time",
      suggestions: ["Close tabs", "Open YouTube", "What can you do?"],
    };
  }

  // 5. Intelligent AI-Powered Voice Response (OpenRouter LLM)
  const openRouterKey =
    customApiKey?.trim() ||
    process.env.OPENROUTER_API_KEY?.trim() ||
    DEFAULT_OPENROUTER_KEY;

  if (openRouterKey) {
    try {
      const systemPrompt = `You are Nova, an advanced, highly articulate and intelligent voice assistant speaking directly with operator ${userLabel || "User"}.
The current accurate system date and time is: ${formatCurrentTime()}.
Answer the user's spoken question accurately, intelligently, and conversationally.
Formatting Rules for Speech:
- Speak directly in 1 to 3 clear, informative, conversational sentences suitable for speech synthesis.
- Never use markdown symbols (no asterisks, no bullets, no headers, no hashtags, no code fences, no emojis).
- Keep pronunciation and sentence rhythm smooth and natural so it sounds wonderful when read aloud.
- If the user asks to open a specific website, include on a new line: ACTION: open_url | <full url>
- If the user asks to close opened tabs, include on a new line: ACTION: close_tabs | all
- At the very end of your response, on a new line, write:
SUGGESTIONS: <2 to 3 comma-separated short suggested follow-up queries>`;

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${openRouterKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://ais-dev-nx6oypjlki5s5wbdaukujz-760004118341.asia-northeast1.run.app",
          "X-Title": "Nova Voice Agent",
        },
        body: JSON.stringify({
          model: "openrouter/auto",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: cleanTranscript },
          ],
          max_tokens: 300,
          temperature: 0.7,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const rawContent = data.choices?.[0]?.message?.content || "";

        if (rawContent.trim()) {
          let replyText = rawContent;
          const suggestions: string[] = [];
          let action: NovaAction | undefined;

          // Parse ACTION if present
          if (replyText.includes("ACTION:")) {
            const lines = replyText.split("\n");
            const actionLine = lines.find((l: string) => l.trim().startsWith("ACTION:"));
            if (actionLine) {
              const actionParts = actionLine.replace("ACTION:", "").split("|").map((p: string) => p.trim());
              if (actionParts[0] === "open_url" && actionParts[1]) {
                action = { type: "open_url", url: actionParts[1] };
              } else if (actionParts[0] === "close_tabs" || actionParts[0] === "close_tab") {
                action = { type: "close_tabs", target: actionParts[1] || "all" };
              }
              replyText = lines.filter((l: string) => !l.trim().startsWith("ACTION:")).join("\n");
            }
          }

          // Parse SUGGESTIONS if present
          if (replyText.includes("SUGGESTIONS:")) {
            const parts = replyText.split("SUGGESTIONS:");
            replyText = parts[0].trim();
            const rawSuggestions = parts[1]?.trim() || "";
            const parsedSuggestions = rawSuggestions
              .split(",")
              .map((s: string) => s.trim().replace(/^[-*•]\s*/, ""))
              .filter((s: string) => s.length > 0 && s.length < 50);

            if (parsedSuggestions.length > 0) {
              suggestions.push(...parsedSuggestions.slice(0, 3));
            }
          }

          replyText = cleanSpokenText(replyText);

          if (!suggestions.length) {
            suggestions.push("Close tabs", "Open Google", "What time is it?");
          }

          return {
            reply: replyText,
            intent: action?.type === "close_tabs" ? "close_tab" : action ? "open_tab" : "general",
            suggestions,
            action,
          };
        }
      }
    } catch (apiError) {
      console.error("AI service error in Nova:", apiError);
    }
  }

  // 6. Smart Local Fallback
  if (hasAny(lower, ["who are you", "what are you", "tell me about nova", "introduce yourself"])) {
    return {
      reply:
        "I am Nova, your voice assistant. I can answer questions, speak responses aloud, check the time, open and close browser tabs, and execute tasks on command.",
      intent: "general",
      suggestions: ["What can you do?", "Open YouTube", "Close tabs"],
    };
  }

  if (hasAny(lower, ["help", "commands", "what can you do", "capabilities"])) {
    return {
      reply:
        "You can ask me any question, request the current time, tell me to open tabs like Google or YouTube, close opened tabs, and I will speak the answers to you. Try tapping the mic or clicking any suggestion.",
      intent: "general",
      suggestions: ["Open YouTube", "Close tabs", "What time is it?"],
    };
  }

  return {
    reply: `I heard: ${cleanTranscript}. You can ask questions, tell me to search the web, open or close tabs, or check the time.`,
    intent: "general",
    suggestions: ["Open Google", "Close tabs", "What time is it?"],
  };
}
