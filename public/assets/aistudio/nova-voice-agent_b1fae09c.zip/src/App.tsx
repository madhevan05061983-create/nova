import { useCallback, useEffect, useState } from "react";
import { AuthActions } from "./components/auth-actions.tsx";
import { NovaConsole } from "./components/nova-console.tsx";

type UserSession = {
  name: string;
  email: string;
  image?: string | null;
  provider?: string;
};

export default function App() {
  const [session, setSession] = useState<UserSession | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSession = useCallback(async () => {
    try {
      const token = localStorage.getItem("nova_session_id");
      const headers: Record<string, string> = {};
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }
      const res = await fetch("/api/auth/session", { headers });
      if (res.ok) {
        const data = await res.json();
        setSession(data.user || null);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    fetchSession().finally(() => {
      setLoading(false);
    });
  }, [fetchSession]);

  const handleSignOut = useCallback(() => {
    try {
      localStorage.removeItem("nova_session_id");
      localStorage.removeItem("nova_auth_success");
    } catch {
      // ignore
    }
    setSession(null);
  }, []);

  const displayName = session?.name ?? session?.email ?? "Operator";
  const email = session?.email ?? "No email available";

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-cyan-400">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
          <p className="text-sm font-medium tracking-wide text-slate-300">Loading Nova Voice Agent…</p>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(34,211,238,0.18),_transparent_35%),linear-gradient(180deg,_#020617_0%,_#07111f_45%,_#0f172a_100%)] px-4 py-6 text-white sm:px-6 lg:px-8">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-6">
        {/* Top Header */}
        <header className="rounded-[2rem] border border-white/10 bg-white/5 px-6 py-5 shadow-[0_20px_80px_rgba(2,6,23,0.35)] backdrop-blur">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="inline-flex items-center justify-center rounded-lg bg-cyan-400/20 px-2.5 py-0.5 text-xs font-bold uppercase tracking-[0.24em] text-cyan-300 border border-cyan-400/30">
                  Nova
                </span>
                <span className="text-xs font-medium text-slate-400">Secure AI Voice Agent</span>
              </div>
              <h1 className="mt-2 text-2xl sm:text-3xl font-semibold tracking-tight text-white">
                Nova Voice Agent
              </h1>
            </div>

            <div className="flex items-center gap-2.5">
              {session && (
                <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-medium text-slate-200 flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Signed in as <strong className="text-white font-semibold">{displayName}</strong></span>
                </div>
              )}
              <AuthActions
                signedIn={Boolean(session)}
                onSignInSuccess={fetchSession}
                onSignOut={handleSignOut}
              />
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        {session ? (
          <NovaConsole displayName={displayName} email={email} onSignOut={handleSignOut} />
        ) : (
          <section className="flex flex-col items-center justify-center rounded-[2.5rem] border border-white/10 bg-white/5 px-6 py-16 sm:py-24 text-center shadow-[0_20px_80px_rgba(2,6,23,0.3)] backdrop-blur">
            {/* Glowing Voice Orb */}
            <div className="relative mb-8 flex items-center justify-center">
              <div className="absolute h-36 w-36 rounded-full bg-cyan-400/20 blur-2xl animate-pulse" />
              <div className="relative flex h-24 w-24 items-center justify-center rounded-full border border-cyan-400/40 bg-slate-900 shadow-[0_0_40px_rgba(34,211,238,0.35)]">
                <svg
                  className="h-10 w-10 text-cyan-300"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3z"
                  />
                </svg>
              </div>
            </div>

            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Activate Nova Voice Agent
            </h2>
            <p className="mt-3 max-w-xl text-base text-slate-300 leading-relaxed">
              Sign in with your Google account to speak or type commands, ask questions, and interact securely with Nova.
            </p>

            {/* Direct Google Sign-In Button */}
            <div className="mt-8 flex flex-col items-center gap-3">
              <AuthActions
                signedIn={false}
                onSignInSuccess={fetchSession}
                onSignOut={handleSignOut}
              />
              <p className="text-xs text-slate-400">
                🔒 Protected by Google OAuth 2.0 with encrypted session handling
              </p>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
