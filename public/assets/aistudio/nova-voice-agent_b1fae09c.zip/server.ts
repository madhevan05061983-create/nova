import express, { Request, Response } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { createNovaResponse } from './src/lib/nova.ts';

dotenv.config();

const PORT = 3000;
const HOST = '0.0.0.0';
const ROOT_DIR = process.cwd();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Fallback to runtime URL or current domain
const DEV_URL = 'https://ais-dev-nx6oypjlki5s5wbdaukujz-760004118341.asia-northeast1.run.app';
const SHARED_URL = 'https://ais-pre-nx6oypjlki5s5wbdaukujz-760004118341.asia-northeast1.run.app';
const APP_URL = (process.env.APP_URL || DEV_URL).replace(/\/+$/, '');

function getInitialCredentials(): { clientId: string; clientSecret: string } {
  // First check if an updated client_secret JSON file was uploaded to assets
  try {
    const assetsDir = path.resolve(ROOT_DIR, 'public/assets/aistudio');
    if (fs.existsSync(assetsDir)) {
      const files = fs.readdirSync(assetsDir);
      const secretFile = files.find((f) => f.startsWith('client_secret_') && f.endsWith('.json'));
      if (secretFile) {
        const fullPath = path.join(assetsDir, secretFile);
        const parsed = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
        const web = parsed.web || parsed.installed;
        if (web?.client_id && web?.client_secret) {
          console.log('Loaded Google OAuth credentials from:', secretFile);
          return { clientId: web.client_id.trim(), clientSecret: web.client_secret.trim() };
        }
      }
    }
  } catch (err) {
    console.warn('Could not read asset credentials file:', err);
  }

  // Fallback to environment variables if provided
  const envId = (process.env.AUTH_GOOGLE_ID || process.env.GOOGLE_CLIENT_ID || '').trim();
  const envSecret = (process.env.AUTH_GOOGLE_SECRET || process.env.GOOGLE_CLIENT_SECRET || '').trim();
  if (envId && envSecret) {
    return { clientId: envId, clientSecret: envSecret };
  }

  return {
    clientId: '693119115954-3j17gsnrspql4saqf1j0haotcdsajuqt.apps.googleusercontent.com',
    clientSecret: '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',
  };
}

const initialCreds = getInitialCredentials();
let activeClientId = initialCreds.clientId;
let activeClientSecret = initialCreds.clientSecret;
let activeAiApiKey = (process.env.OPENROUTER_API_KEY || "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").trim();

process.env.AUTH_GOOGLE_ID = activeClientId;
process.env.AUTH_GOOGLE_SECRET = activeClientSecret;
process.env.OPENROUTER_API_KEY = activeAiApiKey;

type UserSession = {
  id: string;
  name: string;
  email: string;
  image?: string | null;
  provider: 'google' | 'demo';
  createdAt: number;
};

// In-memory session store
const sessions = new Map<string, UserSession>();
const pendingStates = new Set<string>();

function getRedirectUri(req?: Request): string {
  // Always prioritize the APP_URL or request protocol/host
  if (APP_URL && !APP_URL.includes('localhost')) {
    return `${APP_URL}/api/auth/callback/google`;
  }
  if (req) {
    const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    const host = req.headers['x-forwarded-host'] || req.get('host') || `localhost:${PORT}`;
    return `${proto}://${host}/api/auth/callback/google`;
  }
  return `http://localhost:${PORT}/api/auth/callback/google`;
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/api/live' });

  wss.on('connection', async (clientWs: WebSocket) => {
    console.log('Client connected to Live Voice API');

    let session: any = null;
    let isClosed = false;

    try {
      session = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction:
            'You are Nova, an articulate, friendly, and intelligent real-time voice assistant. Always identify yourself as Nova. Speak conversationally, concisely, and naturally. When the user speaks, respond promptly with spoken voice audio.',
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            if (isClosed || clientWs.readyState !== WebSocket.OPEN) return;

            // 1. Audio data: 24kHz raw PCM little-endian
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio) {
              clientWs.send(JSON.stringify({ type: 'audio', audio }));
            }

            // 2. Interrupted event (when user speaks while model is speaking)
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }

            // 3. Output text transcript
            const parts = message.serverContent?.modelTurn?.parts || [];
            for (const p of parts) {
              if (p.text) {
                clientWs.send(JSON.stringify({ type: 'transcript', text: p.text }));
              }
            }

            // 4. Turn complete
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: 'turn_complete' }));
            }
          },
          onerror: (err) => {
            console.error('Gemini Live API error:', err);
            if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'error', error: 'Live API connection error' }));
            }
          },
          onclose: () => {
            console.log('Gemini Live session closed.');
            if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'closed' }));
            }
          },
        },
      });

      clientWs.send(JSON.stringify({ type: 'ready', model: 'gemini-3.8-live' }));
    } catch (err: unknown) {
      console.error('Failed to establish Gemini Live connection:', err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({ type: 'error', error: 'Failed to connect to Gemini Live API' }));
        clientWs.close();
      }
      return;
    }

    clientWs.on('message', (data: Buffer | string) => {
      if (!session || isClosed) return;
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'audio' && msg.audio) {
          session.sendRealtimeInput({
            audio: { data: msg.audio, mimeType: 'audio/pcm;rate=16000' },
          });
        } else if (msg.type === 'text' && msg.text) {
          session.sendRealtimeInput({
            text: msg.text,
          });
        }
      } catch (err) {
        console.warn('Error parsing incoming WS message:', err);
      }
    });

    clientWs.on('close', () => {
      isClosed = true;
      if (session) {
        try {
          session.close();
        } catch {}
      }
    });
  });

  app.use(express.json());
  app.use(cookieParser());

  // Health check endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  // Current OAuth configuration status
  app.get('/api/auth/status', (req: Request, res: Response) => {
    const isConfigured = Boolean(activeClientId && activeClientSecret);
    const redirectUri = getRedirectUri(req);
    const maskedId = activeClientId
      ? `${activeClientId.slice(0, 12)}...${activeClientId.slice(-14)}`
      : null;

    res.json({
      configured: isConfigured,
      hasClientId: Boolean(activeClientId),
      hasClientSecret: Boolean(activeClientSecret),
      hasAiKey: Boolean(activeAiApiKey),
      clientIdPreview: maskedId,
      redirectUri,
      devUrl: DEV_URL,
      sharedUrl: SHARED_URL,
      appUrl: APP_URL,
    });
  });

  // Update OAuth credentials and AI key dynamically
  app.post('/api/auth/config', (req: Request, res: Response) => {
    const { clientId, clientSecret, apiKey } = req.body;

    if (clientId && typeof clientId === 'string' && clientSecret && typeof clientSecret === 'string') {
      activeClientId = clientId.trim();
      activeClientSecret = clientSecret.trim();
      process.env.AUTH_GOOGLE_ID = activeClientId;
      process.env.AUTH_GOOGLE_SECRET = activeClientSecret;
    }

    if (apiKey && typeof apiKey === 'string') {
      activeAiApiKey = apiKey.trim();
      process.env.OPENROUTER_API_KEY = activeAiApiKey;
    }

    res.json({
      ok: true,
      configured: Boolean(activeClientId && activeClientSecret),
      hasAiKey: Boolean(activeAiApiKey),
      message: 'Configuration updated successfully.',
    });
  });

  // Generate OAuth authorization URL
  app.get('/api/auth/url', (req: Request, res: Response) => {
    if (!activeClientId || !activeClientSecret) {
      res.status(400).json({
        error: 'Google OAuth is not configured. Please set AUTH_GOOGLE_ID and AUTH_GOOGLE_SECRET.',
        configured: false,
      });
      return;
    }

    const redirectUri = getRedirectUri(req);
    const state = crypto.randomBytes(24).toString('hex');
    pendingStates.add(state);

    // Expire state after 10 minutes
    setTimeout(() => {
      pendingStates.delete(state);
    }, 10 * 60 * 1000);

    const params = new URLSearchParams({
      client_id: activeClientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'openid email profile',
      state,
      access_type: 'offline',
      prompt: 'consent',
    });

    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

    // Set state cookie with SameSite=None and Secure for iframe popup communication
    res.cookie('nova_oauth_state', state, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 10 * 60 * 1000,
      path: '/',
    });

    res.json({ url: authUrl, redirectUri });
  });

  // Google OAuth callback
  const handleCallback = async (req: Request, res: Response) => {
    const { code, state, error: oauthError } = req.query;

    const renderPopupResult = (success: boolean, message: string, errorDetail?: string, sessionToken?: string) => {
      const escapedMsg = JSON.stringify(message);
      const escapedErr = JSON.stringify(errorDetail || '');
      const escapedToken = JSON.stringify(sessionToken || '');
      return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>${success ? 'Sign-In Successful' : 'Sign-In Failed'} - Nova</title>
    <style>
      body {
        margin: 0;
        font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #020617;
        color: #f8fafc;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        padding: 1.5rem;
        box-sizing: border-box;
      }
      .card {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid ${success ? 'rgba(34, 211, 238, 0.4)' : 'rgba(239, 68, 68, 0.4)'};
        border-radius: 1.5rem;
        padding: 2rem;
        max-width: 400px;
        text-align: center;
        box-shadow: 0 20px 60px rgba(0,0,0,0.5);
      }
      .icon {
        width: 52px;
        height: 52px;
        border-radius: 50%;
        background: ${success ? '#22d3ee' : '#ef4444'};
        color: #020617;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        font-weight: bold;
        margin: 0 auto 1.25rem;
      }
      h2 { margin: 0 0 0.5rem; font-size: 1.35rem; }
      p { margin: 0; color: #94a3b8; font-size: 0.9rem; line-height: 1.5; }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="icon">${success ? '✓' : '!'}</div>
      <h2>${success ? 'Sign-In Successful' : 'Authentication Error'}</h2>
      <p id="status-text">${success ? 'Connecting your Google account to Nova Voice Agent...' : escapedErr || escapedMsg}</p>
    </div>
    <script>
      (function() {
        const success = ${success};
        const token = ${escapedToken};
        if (success) {
          try {
            if (token) localStorage.setItem('nova_session_id', token);
            localStorage.setItem('nova_auth_success', Date.now().toString());
          } catch(e) {}
          try {
            const bc = new BroadcastChannel('nova_auth');
            bc.postMessage({ type: 'OAUTH_AUTH_SUCCESS', sessionId: token });
          } catch(e) {}
          if (window.opener) {
            try {
              window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', sessionId: token }, '*');
            } catch(e) {}
          }
        } else {
          if (window.opener) {
            try {
              window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: ${escapedErr} }, '*');
            } catch(e) {}
          }
        }
        setTimeout(() => {
          try { window.close(); } catch(e) {}
        }, 900);
      })();
    </script>
  </body>
</html>`;
    };

    if (oauthError) {
      res.status(400).send(renderPopupResult(false, 'Google Sign-In canceled or denied.', String(oauthError)));
      return;
    }

    if (!code || typeof code !== 'string') {
      res.status(400).send(renderPopupResult(false, 'Authorization code missing in callback.'));
      return;
    }

    try {
      const redirectUri = getRedirectUri(req);

      // Exchange authorization code for tokens
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: activeClientId,
          client_secret: activeClientSecret,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code',
        }),
      });

      if (!tokenResponse.ok) {
        const errData = await tokenResponse.text();
        console.error('Google token exchange error:', errData);
        res.status(400).send(renderPopupResult(false, 'Failed to exchange authorization code with Google.', errData));
        return;
      }

      const tokenData = await tokenResponse.json();
      const accessToken = tokenData.access_token;

      // Fetch user profile info from Google
      const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });

      if (!userInfoResponse.ok) {
        const errInfo = await userInfoResponse.text();
        res.status(400).send(renderPopupResult(false, 'Failed to retrieve Google profile.', errInfo));
        return;
      }

      const userInfo = await userInfoResponse.json();
      const sessionId = crypto.randomBytes(32).toString('hex');

      const session: UserSession = {
        id: sessionId,
        name: userInfo.name || userInfo.email?.split('@')[0] || 'Operator',
        email: userInfo.email || 'unknown@google.com',
        image: userInfo.picture || null,
        provider: 'google',
        createdAt: Date.now(),
      };

      sessions.set(sessionId, session);

      // Set cookie for session (SameSite=None, Secure for cross-origin iframe preview)
      res.cookie('nova_session', sessionId, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/',
      });

      res.send(renderPopupResult(true, `Signed in as ${session.name}`, undefined, sessionId));
    } catch (err: unknown) {
      console.error('OAuth Callback Exception:', err);
      const errMsg = err instanceof Error ? err.message : 'Unknown authentication error';
      res.status(500).send(renderPopupResult(false, 'Internal server error during authentication.', errMsg));
    }
  };

  app.get('/api/auth/callback/google', handleCallback);
  app.get('/api/auth/callback/google/', handleCallback);

  // Helper to extract session
  const getSessionFromReq = (req: Request): UserSession | null => {
    const sessionId = req.cookies?.nova_session || (req.headers['authorization']?.replace(/^Bearer\s+/i, ''));
    if (!sessionId) return null;
    return sessions.get(sessionId) || null;
  };

  // Get current active session
  app.get('/api/auth/session', (req: Request, res: Response) => {
    const session = getSessionFromReq(req);
    if (!session) {
      res.json({ user: null });
      return;
    }
    res.json({
      user: {
        name: session.name,
        email: session.email,
        image: session.image,
        provider: session.provider,
      },
    });
  });

  // Demo sign-in for testing Nova Voice Agent immediately
  app.post('/api/auth/demo-signin', (req: Request, res: Response) => {
    const { name, email } = req.body || {};
    const sessionId = crypto.randomBytes(32).toString('hex');

    const session: UserSession = {
      id: sessionId,
      name: name || 'Operator (Demo)',
      email: email || 'operator.demo@example.com',
      image: null,
      provider: 'demo',
      createdAt: Date.now(),
    };

    sessions.set(sessionId, session);

    res.cookie('nova_session', sessionId, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 24 * 60 * 60 * 1000,
      path: '/',
    });

    res.json({
      ok: true,
      user: {
        name: session.name,
        email: session.email,
        image: session.image,
        provider: session.provider,
      },
    });
  });

  // Sign out endpoint
  app.post('/api/auth/signout', (req: Request, res: Response) => {
    const sessionId = req.cookies?.nova_session;
    if (sessionId) {
      sessions.delete(sessionId);
    }
    res.clearCookie('nova_session', {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      path: '/',
    });
    res.json({ ok: true });
  });

  // Protected Nova voice agent endpoint
  app.post('/api/nova', async (req: Request, res: Response) => {
    const session = getSessionFromReq(req);
    if (!session) {
      res.status(401).json({
        error: 'Unauthorized: Sign in with Google to speak with Nova.',
      });
      return;
    }

    const { transcript } = req.body || {};
    if (typeof transcript !== 'string' || !transcript.trim()) {
      res.status(400).json({ error: 'Transcript is required' });
      return;
    }

    try {
      const displayName = session.name || session.email || 'Operator';
      const result = await createNovaResponse(transcript, displayName, activeAiApiKey);

      res.setHeader('Cache-Control', 'no-store');
      res.json(result);
    } catch (err: unknown) {
      console.error('Error executing Nova response:', err);
      res.status(500).json({
        reply: 'I encountered an error processing your request. Please try again.',
        intent: 'general',
        suggestions: ['What can you do?', 'Summarize security', 'Sign out'],
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(ROOT_DIR, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(ROOT_DIR, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, HOST, () => {
    console.log(`Nova Voice Agent server running at http://${HOST}:${PORT}`);
    console.log(`Authorized Redirect URI: ${getRedirectUri()}`);
    console.log(`Live Voice API WebSocket mounted at ws://${HOST}:${PORT}/api/live`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
